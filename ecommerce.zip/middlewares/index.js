const { validateSignUp, checkIfUserExists, validateLogin } = require('./user');
const { validateProductAddition, checkIfProductExists, checkIfProductIsForCurrentUser } = require('./product');
const { authenticate, verifyProductNotForCurrentUser, verifyUserHasNotRatedProductBefore } = require('./auth');

module.exports = {
  validateSignUp,
  validateLogin,
  validateProductAddition,
  checkIfUserExists,
  authenticate,
  checkIfProductExists,
  checkIfProductIsForCurrentUser,
  verifyProductNotForCurrentUser,
  verifyUserHasNotRatedProductBefore,
};
