const userModel = require('./user');
const productModel = require('./product');

module.exports = { userModel, productModel };
