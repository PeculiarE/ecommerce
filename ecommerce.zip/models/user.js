const userModel = [
  {
    id: '719a6c77-f46e-43ba-bbdb-fd7fa890af71',
    firstName: 'Peculiar',
    lastName: 'Erhis',
    email: 'perhis@gmail.com',
    storeName: 'Peculiar Stores',
    phoneNumber: '081-2643-2823',
    password: 'Princess26',
    createdAt: '',
    updatedAt: '',
  },
];

module.exports = userModel;
