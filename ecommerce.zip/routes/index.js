const userRouter = require('./user');
const productRouter = require('./product');

module.exports = { userRouter, productRouter };
