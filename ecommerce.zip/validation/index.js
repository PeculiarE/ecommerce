const addProductSchema = require('./product');
const { signUpSchema, loginSchema } = require('./user');

module.exports = { addProductSchema, signUpSchema, loginSchema };
